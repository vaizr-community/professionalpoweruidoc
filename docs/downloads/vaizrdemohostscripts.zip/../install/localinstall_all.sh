#!/bin/sh
cd
#
# Specifies a valid locale for the environment .
#
sudo locale-gen UTF-8
#
#
# downloads the package lists from the repositories and "updates" them to get
# information on the newest versions of packages and their dependencies.
# It will do this for all repositories and PPAs.
# From http://linux.die.net/man/8/apt-get:
#
sudo apt-get update
#
# install ansible
#
sudo apt-get -q -y install ansible
#
# install mercurial
#
sudo apt-get -q -y install mercurial
#
# mkdir workspaces
#
mkdir -p workspaces
#
# cd workspaces
#
cd workspaces
#
# hg clone https://vaizrdemo:vaizr19651229@bitbucket.org/vaizr/vaizrdemodeployment || true
#
( hg clone https://vaizrdemo:vaizr19651229@bitbucket.org/vaizr/vaizrdemodeployment || true )

#
# To have the ansible environment named after the correct user
# we use symbolic links, we first remove them than create them
( rm ~/workspaces/vaizrdemodeployment/ansible/aws     || true )
( rm ~/workspaces/vaizrdemodeployment/ansible/localvm || true )
( ln -s ~/workspaces/vaizrdemodeployment/ansible/aws     ~/workspaces/vaizrdemodeployment/ansible/ubuntu || true )
( ln -s ~/workspaces/vaizrdemodeployment/ansible/localvm ~/workspaces/vaizrdemodeployment/ansible/vagrant || true )

#
# now we run the ansible-playbook local
#
( cd vaizrdemodeployment/ansible && ansible-playbook -i $USER local2localsite_all.yml -vvvv )
