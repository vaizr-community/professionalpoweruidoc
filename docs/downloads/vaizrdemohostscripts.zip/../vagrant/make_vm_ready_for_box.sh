# remove APT cache
sudo apt-get clean
# Then, “zero out” the drive
sudo dd if=/dev/zero of=/EMPTY bs=1M
sudo rm -f /EMPTY
# Lastly, let’s clear the Bash History and exit the VM
cat /dev/null > ~/.bash_history && history -c && exit
