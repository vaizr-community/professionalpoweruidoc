vagrant destroy
