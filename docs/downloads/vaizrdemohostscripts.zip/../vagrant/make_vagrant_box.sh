pwd=$(pwd)
../clidev/guest_execute.sh $pwd.make_vm_ready_for_box.sh
#sshpass -p vagrant ssh  -o UserKnownHostsFile=/dev/null -o StrictHostKeyChecking=no \
#	           vagrant@localhost -p 2222 < make_vm_ready_for_box.sh
#!/bin/sh
if [ -f "vaizrdemo.box" ]
then
  date_time=$(date +%Y%m%d_%H%M%S_%Z)
  mv  vaizrdemo.box vaizrdemo.box.$date_time
fi
vagrant package --output vaizrdemo.box