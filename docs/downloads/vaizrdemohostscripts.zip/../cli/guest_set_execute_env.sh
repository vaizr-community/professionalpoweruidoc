#!/bin/bash

# This is a program that sets the vaizr demo guest_execute environment variable
echo
echo "Please choose your development environment : "
echo
echo " [1] for local virtual box"
echo " [2] for amazon web services EC2"
echo " [3] for amazon web services Manual EC2"
while true; do
echo
#echo   "lvm [l]"
#echo   "aws [a]"
read -p "Enter your choice [1] " choice
choice=${choice:-"1"}
VAIZRDEMO_GUEST_ENV="LVM"
if   [ "${choice}" == "1" ] ; then
    VAIZRDEMO_GUEST_ENV="LVM" ; break
elif [ "${choice}" == "2" ] ; then
    VAIZRDEMO_GUEST_ENV="AWS" ; break
elif [ "${choice}" == "3" ] ; then
    VAIZRDEMO_GUEST_ENV="AWSMANUAL" ; break
else
     echo "That is not a valid choice, try [1] for lvm of [2,3] for aws"
fi
export $VAIZRDEMO_GUEST_ENV
done
echo
if   [ "${choice}" == "1" ] ; then
        echo "Environment set for local virtual box"
elif [ "${choice}" == "2" ] ; then
        echo "Environment set for amazon web services EC2"
elif [ "${choice}" == "3" ] ; then
        echo "Environment set for amazon web services Manual EC2"
fi
#        echo "This is not a valid choice: [1,2,3] is valid"
#fi
echo "\$VAIZRDEMO_GUEST_ENV = $VAIZRDEMO_GUEST_ENV"
echo