echo "start guest_execute $1"
date
ssh -o UserKnownHostsFile=/dev/null -o StrictHostKeyChecking=no ubuntu@ec2-54-93-171-47.eu-central-1.compute.amazonaws.com -i ./pem/awsvaizrdemobox.pem -X $1
date
echo "finish guest_execute $1"
