echo "start guest_execute $1"
date
ssh  -o UserKnownHostsFile=/dev/null -o StrictHostKeyChecking=no vagrant@localhost -p 2222 -i ./pem/lvmvaizrdemobox.pem -X $1
date
echo "finish guest_execute $1"
