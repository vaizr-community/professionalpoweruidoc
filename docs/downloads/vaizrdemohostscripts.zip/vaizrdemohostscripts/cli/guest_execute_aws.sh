echo "start guest execute"
echo date
ssh -o UserKnownHostsFile=/dev/null -o StrictHostKeyChecking=no ubuntu@$(jq -r '.Reservations[0].Instances[0].PublicDnsName' ../cloud/aws/tmp/vaizrdevelop_$(echo $USER)_describe.json) -i ~/.aws/vaizrdev.pem -X $1
echo date
echo "finish guest execute"
