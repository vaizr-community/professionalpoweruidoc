echo "AWS hostname "
echo $(jq -r '.Reservations[0].Instances[0].PublicDnsName' ../cloud/aws/tmp/vaizrdevelop_$(echo $USER)_describe.json)
echo
