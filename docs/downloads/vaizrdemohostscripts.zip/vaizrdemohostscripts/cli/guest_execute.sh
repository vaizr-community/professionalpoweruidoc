if [ -z ${VAIZRDEMO_GUEST_ENV+x} ]; 
then
   echo 
   echo "VAIZRDEMO_GUEST_ENV is unset"; 
   echo 
   echo "Are you sure you run your script with a dot ?"
   echo "ie . ./firefox instead of ./firefox"
   echo 
   echo "otherwise"
   echo 
   echo "Please run the following satement first"
   echo ". ./guest_set_execute_env.sh"
   echo 
else 
   echo
   echo "VAIZRDEMO_GUEST_ENV is set to $VAIZRDEMO_GUEST_ENV"
   echo 
   if   [ "${VAIZRDEMO_GUEST_ENV}" == "LVM" ]
   then
     ./guest_execute_lvm.sh $1;
   elif [ "${VAIZRDEMO_GUEST_ENV}" == "AWS" ]
   then
     ./guest_execute_aws.sh $1;     
   elif [ "${VAIZRDEMO_GUEST_ENV}" == "AWSMANUAL" ]
   then
     ./guest_execute_awsmanual.sh $1;     
   fi
fi