#!/usr/bin/env bash
echo 'begin time install script'
date
##(vagrant destroy; vagrant init ubuntu/trusty64 && vagrant up )
(cd ./../vagrant && vagrant destroy; vagrant up --provider virtualbox )
#(cd vagrant && exec ./destroy_vagrant_machine.sh)
#(cd vagrant && exec ./create_vagrant_machine.sh)
echo 'start localinstall_all.sh'
sshpass -p vagrant ssh  -o UserKnownHostsFile=/dev/null -o StrictHostKeyChecking=no \
	vagrant@localhost -p 2222 < localinstall_all.sh
echo 'finish localinstall_all.sh'
date
echo 'end time install script'
