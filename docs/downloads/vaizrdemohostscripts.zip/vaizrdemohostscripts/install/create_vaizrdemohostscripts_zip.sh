zip -r vaizrdemohostscripts.zip ./../cli ./../install ./../vagrant -x *.vagrant* *.DS_Store*
