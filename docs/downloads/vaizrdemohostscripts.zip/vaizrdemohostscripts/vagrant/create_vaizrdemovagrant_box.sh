vagrant package --base vaizrdemobox --output ./../vaizrdemovagrant.box --vagrantfile Vagrantfile
